Logs filel contail Encrypted data.

To decrypt the data execute decrypt.sh
change decrypt.sh to +x permission
    chmod +x decrypt.sh 
Run decrypt.sh as root to decryt the data.
    sudo decrypt.sh